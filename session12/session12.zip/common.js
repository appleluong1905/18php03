//alert('external demo');
document.write('Hello');
document.getElementById("demo").innerHTML = 'Xin chao demo';