$('#register').click(function(){
	var name = $('#name').val();
	var phone = $('#phone').val();
	
	$('#show-name').text(name);
	$('#show-phone').text(phone);
});